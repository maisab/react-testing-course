export const stack = {
  id: 0,
  title: 'test title',
  cards: [
    { id: 0, prompt: 'test prompt', answer: 'test answer' },
    { id: 1, prompt: 'test prompt 2', answer: 'test answer 2' }
  ]
};

export const stacks = [stack];